<?php

/**

 * The template for displaying the footer
*/
?>
  <footer class="footer-wrapper">
   </footer>
    <?php wp_footer(); ?>
</body>

</html>

